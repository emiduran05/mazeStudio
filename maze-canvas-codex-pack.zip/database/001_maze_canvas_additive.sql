-- REFERENCE ONLY. Adapt ID types/table names/timestamp conventions to the real DB.
-- ADDITIVE: never drop or mutate Block content.
BEGIN;

ALTER TABLE steps
ADD COLUMN IF NOT EXISTS content_mode VARCHAR(20) NOT NULL DEFAULT 'BLOCKS';

ALTER TABLE steps
DROP CONSTRAINT IF EXISTS steps_content_mode_check;

ALTER TABLE steps
ADD CONSTRAINT steps_content_mode_check
CHECK (content_mode IN ('BLOCKS', 'CANVAS'));

-- If Maze Studio uses UUID Step IDs, keep UUID. If not, adapt before execution.
CREATE TABLE IF NOT EXISTS step_canvas_pages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    step_id UUID NOT NULL REFERENCES steps(id) ON DELETE CASCADE,
    position INTEGER NOT NULL,
    title VARCHAR(160),
    schema_version INTEGER NOT NULL DEFAULT 1,
    document_json JSONB NOT NULL DEFAULT
      '{"schemaVersion":1,"page":{"width":1280,"height":720,"background":{"type":"SOLID","value":"#FFFFFF"}},"elements":[]}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (position >= 0),
    UNIQUE (step_id, position)
);

CREATE INDEX IF NOT EXISTS idx_step_canvas_pages_step
ON step_canvas_pages(step_id);

COMMIT;
