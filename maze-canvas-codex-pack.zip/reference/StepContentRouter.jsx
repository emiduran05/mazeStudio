// Reference only — adapt to real components.
export default function StepContentRouter({ step }) {
  if (step.content_mode === "CANVAS") {
    return <CanvasStepViewer stepId={step.id} />;
  }
  return <ExistingBlockStepViewer stepId={step.id} />;
}
