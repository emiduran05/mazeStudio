# Undo/redo

Store immutable Maze document state.

Do not push history on each `dragmove`.

```text
dragstart → remember pre-change state
dragmove → local visual updates
dragend → commit Maze coordinates → one history entry → autosave
```

Use the same pattern for resize/rotation. Group text typing with debounce/blur commits.
