export const emptyCanvasDocument = {
  schemaVersion: 1,
  page: {
    width: 1280,
    height: 720,
    background: { type: "SOLID", value: "#FFFFFF" },
  },
  elements: [],
};

export function createTextElement() {
  return {
    id: crypto.randomUUID(),
    type: "TEXT",
    x: 100,
    y: 100,
    width: 420,
    height: 100,
    rotation: 0,
    zIndex: 1,
    locked: false,
    content: { text: "Double click to edit" },
    style: {
      fontFamily: "Inter",
      fontSize: 36,
      fontWeight: 600,
      fill: "#171927",
      align: "left",
    },
  };
}
