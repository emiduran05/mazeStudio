# V1 scope

Must have:
- Pages
- templates
- text
- images
- shapes/lines
- drag/resize/rotate
- selection
- duplicate/delete
- copy/paste
- undo/redo
- z-order
- zoom
- snapping/alignment
- keyboard shortcuts
- autosave
- preview
- learner read-only rendering

Later:
- groups
- multi-select
- image crop
- gradients
- richer tables
- SVG library
- animations
- real-time collaboration

Not V1:
- video editing
- audio timeline
- background remover
- Canva-scale template marketplace
- full vector illustration suite
