# Activities and Challenges

Canvas content teaches/explains.

Quick Activities provide immediate practice and may later use `ACTIVITY_REF`. They should render as React/HTML for the learner.

Challenges remain independent domain entities because they already own attempts, grades, feedback, private links and progress.

Do not move Challenge data into Canvas JSON.

V1 recommendation: if inline Activities complicate delivery, ship content-only Canvas first and add Activity references in V1.1.
