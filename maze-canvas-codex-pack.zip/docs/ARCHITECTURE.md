# Architecture

```text
Learning Journey
└── Stage
    └── Step
        ├── content_mode: BLOCKS
        │   └── existing Step Blocks
        └── content_mode: CANVAS
            ├── Canvas Page 1 → Maze JSON
            ├── Canvas Page 2 → Maze JSON
            └── Canvas Page N → Maze JSON

Step
├── existing Challenges
└── optional Activity references
```

Suggested frontend organization (adapt to repo):

```text
components/mazeCanvas/
  MazeCanvasEditor.jsx
  MazeCanvasStage.jsx
  MazeCanvasToolbar.jsx
  MazeCanvasSidebar.jsx
  MazeCanvasInspector.jsx
  MazeCanvasPages.jsx
  elements/
  adapters/
  hooks/
  state/

pages/studio/CanvasLab.jsx
```

Suggested backend additions:

```text
canvasPageModel.js
canvasPageService.js
canvasPageController.js
canvasPageRoutes.js
```

Reuse current auth, ownership, collaborators and error handling.
