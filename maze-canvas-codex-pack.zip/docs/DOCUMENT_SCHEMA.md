# Maze document schema

Canonical app data is Maze JSON, not Konva JSON.

Example:

```json
{
  "schemaVersion": 1,
  "page": {
    "width": 1280,
    "height": 720,
    "background": {"type":"SOLID","value":"#FFFFFF"}
  },
  "elements": [
    {
      "id": "uuid",
      "type": "TEXT",
      "x": 80,
      "y": 70,
      "width": 620,
      "height": 100,
      "rotation": 0,
      "zIndex": 1,
      "locked": false,
      "content": {"text":"Introduction to React"},
      "style": {
        "fontFamily":"Inter",
        "fontSize":48,
        "fontWeight":700,
        "fill":"#171927",
        "align":"left"
      }
    }
  ]
}
```

Core content types:
- TEXT
- IMAGE
- SHAPE
- LINE
- CODE
- VIDEO_EMBED
- FILE_LINK
- ACTIVITY_REF

Every document includes `schemaVersion`. Add a future `upgradeCanvasDocument()` adapter so old Pages remain readable.
