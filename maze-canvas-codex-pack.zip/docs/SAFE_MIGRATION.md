# Safe migration

## Phase 0
Install packages, add feature flag, additive DB storage. No UI behavior changes.

## Phase 1
Canvas Lab only. No production Step switches.

## Phase 2
One internal test Step uses CANVAS.

## Phase 3
Expose Canvas (Beta) to selected/development users.

## Phase 4
Allow opt-in for newly created Steps. Do not change default until validated.

## Rollback

```text
VITE_ENABLE_MAZE_CANVAS=false
```

Canvas DB rows remain safely unused. No DROP statements are needed.

Never delete Blocks on mode switch. Never delete Canvas pages on switch back.
