# Acceptance tests

## Legacy safety
- open old Block Step;
- edit/reorder Blocks;
- upload image Block;
- preview;
- learner render;
- verify behavior unchanged.

## Feature flag
- disable Canvas;
- Canvas UI disappears;
- build passes;
- Blocks still work.

## Persistence
- create Page;
- add text/image/shape;
- move/resize;
- save;
- refresh;
- verify identical state.

## Undo/redo
Test add, move, resize, delete, text edit, duplicate.

## Switching modes
- BLOCKS Step with content;
- switch CANVAS and create Pages;
- switch BLOCKS and verify old Blocks;
- switch CANVAS and verify Pages.

## Pages
Create, duplicate, reorder, rename, delete with confirmation.

## Assets
Verify remote URL persistence and no base64 inside document JSON.

## Student
- BLOCKS uses legacy renderer;
- CANVAS uses new viewer;
- mobile scaling;
- links/files/video usable.

## Permissions
Owner/collaborator according to current permissions can edit; learner cannot; unauthorized user cannot load Canvas data.

## Performance
Test at least 100 elements/page, 10 Pages, image-heavy page, and confirm no network save spam during dragmove.

Run builds/lint/tests.
