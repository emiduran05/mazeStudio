# Maze Studio — Maze Canvas Safe Migration Pack

This pack is for Codex to integrate a Canva-inspired Step editor into the existing Maze Studio project using Konva + react-konva, without removing or breaking the current Block editor.

Core strategy:

```text
Existing Step
├── content_mode = BLOCKS   ← current system stays untouched
└── content_mode = CANVAS   ← new editor, opt-in per Step
```

The Block Builder stays the default until Maze Canvas is proven stable.

Use `CODEX_TASK.md` as Codex's main instruction.
