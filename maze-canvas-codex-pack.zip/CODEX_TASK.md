# Codex Task — Add Maze Canvas without breaking Blocks

Work directly inside the existing Maze Studio repository.

## Absolute rule

The existing Block system must remain fully functional. Do not replace it in-place and do not delete its tables, APIs, routes, components, styles, migrations, or student renderer.

Implement Maze Canvas as a parallel, opt-in Step content mode.

## 1. Inspect first

Before editing, inspect:
- frontend package manager and React version;
- current Step Builder;
- Block editor and learner Block renderer;
- Step and Block schemas;
- upload/storage services;
- authorization/collaborator checks;
- autosave conventions;
- current tests and CSS tokens.

Report what you found before changing architecture.

## 2. Add Konva safely

Install with the project's package manager:

```bash
npm install konva react-konva use-image
```

Choose versions compatible with the actual React version and lockfile.

Konva is the graphics/interaction engine only. Maze Studio owns the canonical document schema, persistence, toolbar, templates, uploads, activities, permissions, and learner rendering.

Do not persist native Konva serialization as the canonical DB format.

## 3. Add parallel Step modes

Each Step supports:

```text
BLOCKS
CANVAS
```

Existing Steps remain `BLOCKS` by default.

Never delete Block data when switching to CANVAS. Never delete Canvas pages when switching back to BLOCKS.

This must be reversible per Step.

## 4. Feature flag

Add/use a feature flag such as:

```env
VITE_ENABLE_MAZE_CANVAS=true
```

When disabled, Canvas controls/routes disappear and Maze Studio behaves exactly as before.

## 5. Build Canvas Lab first

Create an isolated experimental route such as:

```text
/studio/canvas-lab
```

or

```text
/studio/canvas-lab/:stepId
```

Do not alter real Step content while prototyping.

Implement here first:
- fixed logical page size;
- selection;
- drag;
- resize;
- rotate;
- delete;
- duplicate;
- copy/paste;
- undo/redo;
- layers/z-order;
- zoom;
- snap/alignment guides;
- keyboard shortcuts;
- text;
- image;
- shapes;
- multiple Pages;
- save/reload from Maze JSON.

Do not integrate into Step Builder until this passes acceptance tests.

## 6. Maze Canvas V1 scope

Content elements:
- TEXT
- IMAGE
- SHAPE
- LINE
- CODE
- VIDEO_EMBED
- FILE_LINK
- simple TABLE or placeholder

Do not recreate Canva. Build an educational page composer.

## 7. Pages

A Canvas Step may contain multiple Pages:

```text
Step
├── Page 1
├── Page 2
├── Page 3
└── Challenges remain outside Canvas JSON
```

Support add, duplicate, rename, delete, reorder and thumbnails.

## 8. Templates

Provide templates before blank canvas:
- Title + body
- Image + text
- Text + image
- Full image + caption
- Explanation
- Example
- Summary
- Blank

Templates create normal Maze JSON elements and remain fully editable.

## 9. Challenges stay independent

Do not convert Challenges to Canvas elements.

Existing Challenge infrastructure remains the authority for attempts, grading, feedback, private links and progress.

Canvas may display a reference card/chip to a Challenge ID, but never serialize the Challenge itself into `document_json`.

## 10. Lightweight Activities

Reserve an element type:

```text
ACTIVITY_REF
```

It stores only an activity ID/display variant. Actual interactivity is React/HTML in learner view, not static Canvas graphics.

If existing exercise Blocks can be reused safely as the backing Activity, reuse them. Otherwise keep `ACTIVITY_REF` behind a feature flag and ship Canvas content-only first.

Do not block Canvas V1 on Activities.

## 11. Canonical Maze JSON

Use Maze-owned JSON such as:

```json
{
  "schemaVersion": 1,
  "page": {
    "width": 1280,
    "height": 720,
    "background": {"type":"SOLID","value":"#FFFFFF"}
  },
  "elements": []
}
```

Element shape:

```json
{
  "id": "uuid",
  "type": "TEXT",
  "x": 100,
  "y": 100,
  "width": 400,
  "height": 100,
  "rotation": 0,
  "zIndex": 1,
  "locked": false,
  "content": {},
  "style": {}
}
```

Architecture:

```text
Maze JSON → adapter → react-konva
```

Konva is an implementation detail.

## 12. Persistence

Use additive storage only. Suggested table:

```text
step_canvas_pages
```

Fields:
- id
- step_id
- position
- title
- schema_version
- document_json
- created_at
- updated_at

Suggested endpoints, adapted to current API conventions:

```http
GET    /api/steps/:stepId/canvas-pages
POST   /api/steps/:stepId/canvas-pages
PUT    /api/canvas-pages/:pageId
DELETE /api/canvas-pages/:pageId
PATCH  /api/steps/:stepId/canvas-pages/reorder
```

Reuse existing ownership/collaborator authorization.

## 13. Autosave

Do not persist every pointer move.

- dragmove → local visual state only
- dragend → commit Maze state + history + autosave
- transformend → one history entry + autosave
- typing → debounce

UI must expose: `Saved`, `Saving...`, `Unsaved changes`, `Save failed — Retry`.

## 14. Undo/redo

History stores immutable Maze document state, not Konva serialization.

Group drag/resize operations into one history entry each.

## 15. Existing storage for assets

Reuse current Maze upload/storage API.

Flow:

```text
select image → Maze upload → remote URL → IMAGE element URL
```

Do not store base64 image data in Canvas JSON.

## 16. Text editing

Recommended UX:
- click selects;
- double-click edits;
- render DOM textarea/contenteditable overlay for editing;
- commit back to Maze JSON;
- Escape/blur exits.

## 17. Student rendering

BLOCKS Steps continue using the exact existing renderer.

CANVAS Steps use a new read-only renderer:

```jsx
if (step.content_mode === "CANVAS") {
  return <CanvasStepViewer />;
}
return <ExistingBlockStepViewer />;
```

For links, files, embeds and activities, use React/HTML overlays where needed for accessibility/interactivity.

## 18. Responsive strategy

Author at fixed logical size, e.g. 1280×720. Scale uniformly to fit viewport. On mobile, show Pages vertically and scale to width. Do not rewrite coordinates per device.

## 19. Safe mode switching

Only when feature flag is enabled show:

```text
Content editor
● Blocks
○ Canvas (Beta)
```

Warn that switching modes does not delete the other representation.

No destructive auto-conversion.

## 20. Optional Block → Canvas draft later

After V1 is stable, optionally add `Create Canvas draft from Blocks`.

This must be one-way, opt-in, and preserve original Blocks.

Unsupported Blocks become visible placeholders; never silently discard them.

## 21. UX target

```text
┌────────────────────────────────────────────────────────────┐
│ Back   Step title       Undo Redo    Preview     Save      │
├─────────────┬──────────────────────────────┬───────────────┤
│ Templates   │                              │ Properties    │
│ Text        │        Canvas Page           │               │
│ Media       │                              │ Position      │
│ Elements    │                              │ Size          │
│ Activities  │                              │ Typography    │
│ Uploads     │                              │ Appearance    │
├─────────────┴──────────────────────────────┴───────────────┤
│ Page 1      Page 2      Page 3       +                    │
└────────────────────────────────────────────────────────────┘
```

Use Maze Studio visual language, not Canva branding.

## 22. Performance

- normalized editor state;
- memoized element components;
- lazy-load Canvas editor bundle;
- avoid loading every Step/Canvas document at once;
- test 100+ elements/page;
- test image-heavy pages.

## 23. Rollback proof

Implementation is incomplete unless this works:
1. Disable Canvas feature flag.
2. Restart.
3. Existing Block Steps behave exactly as before.
4. No Block data changed/deleted.
5. Re-enable flag.
6. Canvas Steps return unchanged.

## 24. Do NOT

- delete Block editor;
- migrate all Steps automatically;
- rename/drop Block tables;
- store Konva nodes as canonical data;
- store base64 images in JSON;
- put Challenges inside Canvas JSON;
- force Canvas on existing teachers;
- alter BLOCKS student rendering;
- ship without feature flag/rollback.

## 25. Tests/build

Run available frontend build/lint, backend tests/lint, and existing Block/Step tests. Add tests from `docs/ACCEPTANCE_TESTS.md`.

## Final report

Report packages installed, files created/modified, DB migration proposal, existing Block code touched, routes/endpoints, feature flag, tests, performance observations, limitations, and exact rollback procedure.
