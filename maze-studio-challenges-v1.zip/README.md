# Maze Studio — Challenges v1

Pack for Codex to implement a complete Challenge system in the existing Maze Studio repository.

Includes:
- many-to-many Challenge ↔ Step relationships;
- multiple attempts;
- real server-side grading;
- learner progress;
- teacher review;
- private links for unregistered learners;
- database migration;
- API and security requirements.

Use `CODEX_TASK.md` as Codex's main instruction.
