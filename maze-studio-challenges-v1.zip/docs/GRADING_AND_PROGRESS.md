# Grading and progress rules

## Automatic grading

- SINGLE_CHOICE / TRUE_FALSE: full points for exact correct option.
- MULTIPLE_CHOICE: exact correct set for v1.
- FILL_BLANK: configurable normalization.

## Manual grading

- SHORT_ANSWER
- LONG_ANSWER
- FILE_UPLOAD

These remain `PENDING_REVIEW` until the educator assigns points.

## Multiple attempts

- Every attempt remains stored.
- Best percentage controls Challenge progress.
- Latest attempt remains visible.
- `max_attempts = NULL` means unlimited.

## Statuses

- NOT_STARTED
- IN_PROGRESS
- SUBMITTED
- PASSED
- FAILED
- PENDING_REVIEW

## Step completion

A Step cannot be completed until every required linked Challenge satisfies its completion policy.

Since one Challenge may be linked to several Steps, one successful Challenge can satisfy all those Step requirements without duplicating attempts.
