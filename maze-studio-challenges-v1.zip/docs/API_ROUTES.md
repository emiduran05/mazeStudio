# API routes

## Learner

```http
GET  /api/learner/challenges/:challengeId
POST /api/learner/challenges/:challengeId/attempts
GET  /api/learner/challenges/:challengeId/attempts
GET  /api/learner/challenge-attempts/:attemptId
```

## Educator

```http
POST   /api/challenges
GET    /api/challenges/:challengeId
PUT    /api/challenges/:challengeId
DELETE /api/challenges/:challengeId
POST   /api/challenges/:challengeId/steps
DELETE /api/challenges/:challengeId/steps/:stepId
GET    /api/challenges/:challengeId/attempts
PUT    /api/challenge-attempts/:attemptId/review
POST   /api/challenges/:challengeId/private-links
GET    /api/challenges/:challengeId/private-links
PATCH  /api/challenge-private-links/:linkId
DELETE /api/challenge-private-links/:linkId
```

## Public private-link routes

```http
GET  /api/public/challenges/private/:token
POST /api/public/challenges/private/:token/session
POST /api/public/challenges/private/:token/attempts
GET  /api/public/challenges/private/:token/attempts/:attemptToken
```
