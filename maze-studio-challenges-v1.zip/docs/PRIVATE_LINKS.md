# Private links

Private links allow a learner without an account to open and submit a Challenge.

## Security

- raw token: shown only in the URL;
- database: SHA-256 hash only;
- minimum 32 random bytes;
- expiration, revocation and max-use support;
- optional allowed email;
- optional access code;
- optional guest name/email;
- anonymous session token also stored only as a hash;
- rate limiting;
- no raw token logging.

Do not create fake users. Anonymous attempts reference a private access session.

A later account-claim flow must verify email or a one-time claim token before linking anonymous attempts.
