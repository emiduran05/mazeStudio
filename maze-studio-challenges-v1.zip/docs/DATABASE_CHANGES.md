# What must be added to PostgreSQL

Required concepts:

1. `challenges`
   Main Challenge configuration.

2. `challenge_steps`
   Many-to-many relationship. This is what allows one Challenge to belong to several Steps.

3. `challenge_questions`
   Learner-facing questions and options.

4. `challenge_answer_keys`
   Correct answers and grading secrets, separated so learner APIs cannot leak them.

5. `challenge_attempts`
   One immutable row per attempt. Supports either a registered learner or a private-link session.

6. `challenge_attempt_answers`
   Each submitted answer and its awarded points.

7. `learner_challenge_progress`
   Attempt count, best score, latest attempt and completion/pass state.

8. `challenge_private_links`
   Expiring/revocable private links.

9. `challenge_private_access_sessions`
   Anonymous sessions for users without accounts.

10. `challenge_attempt_grade_events`
    Audit history for manual grading and overrides.

Also keep your existing Step progress table. After an attempt is graded, recalculate every linked Step and the Journey.
