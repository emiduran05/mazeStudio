# Codex task — Implement Challenges v1

Work inside the existing Maze Studio repository. Do not create a new project.

## Inspect first

Locate and reuse:
- existing auth middleware and `/auth/me`;
- users, Learning Journeys, Stages, Steps, enrollments and progress tables;
- current Challenge code, if any;
- API request helpers;
- educator permissions/collaborators;
- file storage abstraction;
- StudentLayout and StudioLayout.

Adapt all names to the real project.

## Product requirements

A Challenge:
- belongs to a Learning Journey;
- can be linked to one or several Steps;
- can be required or optional per Step;
- supports multiple attempts;
- may have a finite attempt limit or unlimited attempts;
- stores every attempt independently;
- receives a real score calculated by the backend;
- can use automatic, manual or hybrid grading;
- updates learner Challenge progress;
- affects Step and Journey progress;
- can be shared using a private link with a learner who has no account.

## V1 types

- SINGLE_CHOICE
- MULTIPLE_CHOICE
- TRUE_FALSE
- FILL_BLANK
- SHORT_ANSWER
- LONG_ANSWER
- FILE_UPLOAD

Keep the design extensible for CODING, MATCHING and ORDERING.

## Grading

Modes:
- AUTO
- MANUAL
- HYBRID

The frontend sends answers only. Never trust a frontend score, percentage, correctness flag or points value.

AUTO:
- SINGLE_CHOICE / TRUE_FALSE: full points only for the correct option.
- MULTIPLE_CHOICE: exact-set match for v1.
- FILL_BLANK: normalize whitespace, optional case sensitivity and optional accent removal.

MANUAL:
- SHORT_ANSWER
- LONG_ANSWER
- FILE_UPLOAD

Manual attempts stay `PENDING_REVIEW` until reviewed.

HYBRID:
- keep automatic score;
- allow teacher adjustment;
- record every override in an audit table.

## Multiple attempts

- Never overwrite an earlier attempt.
- Number attempts per Challenge and actor.
- Use a transaction and row locking to prevent duplicate attempt numbers.
- `max_attempts = NULL` means unlimited.
- Best graded attempt drives progress.
- Store both best and latest attempt.

## Challenge ↔ Steps

Use a junction table. Do not use a single `step_id` as the only relationship.

One Challenge may satisfy requirements in several Steps. Attempts are stored once per Challenge, not once per Step.

After submission or review:
1. update Challenge progress;
2. recalculate every Step linked through the junction table;
3. recalculate Journey progress.

A Step may be completed only when all required linked Challenges satisfy their completion policy.

## Registered learner access

Learner endpoints must verify:
- authenticated user;
- ACTIVE enrollment in the Journey;
- published Challenge;
- release date and deadline;
- Step lock/progression policy when applicable;
- attempt limit.

A learner can only view their own attempts.

## Private links for unregistered learners

Create public routes:

```http
GET  /api/public/challenges/private/:token
POST /api/public/challenges/private/:token/session
POST /api/public/challenges/private/:token/attempts
GET  /api/public/challenges/private/:token/attempts/:attemptToken
```

Private-link rules:
- generate at least 32 cryptographically secure random bytes;
- store only SHA-256 token hashes;
- never log raw tokens;
- support expiration;
- support revocation;
- support maximum uses;
- support optional allowed email;
- support optional access code;
- support optional guest name/email collection;
- support attempt-limit override;
- rate-limit all public routes.

Opening a private link creates an anonymous access session. Do not create a fake user.

Anonymous attempts reference the private access session. A guest must only access their own result using an opaque attempt/session token.

If a guest registers later, create a verified claim flow. Do not claim attempts merely because an unverified email matches.

## Database

Adapt and apply `database/001_challenges_v1.sql`.

Before applying:
- inspect existing tables;
- merge with existing Challenge schema instead of duplicating concepts;
- add real foreign keys;
- preserve data;
- use a migration.

## Backend endpoints

Teacher:

```http
POST   /api/challenges
GET    /api/challenges/:challengeId
PUT    /api/challenges/:challengeId
DELETE /api/challenges/:challengeId
POST   /api/challenges/:challengeId/steps
DELETE /api/challenges/:challengeId/steps/:stepId
GET    /api/challenges/:challengeId/attempts
GET    /api/challenge-attempts/:attemptId
PUT    /api/challenge-attempts/:attemptId/review
POST   /api/challenges/:challengeId/private-links
GET    /api/challenges/:challengeId/private-links
PATCH  /api/challenge-private-links/:linkId
DELETE /api/challenge-private-links/:linkId
```

Learner:

```http
GET  /api/learner/challenges/:challengeId
POST /api/learner/challenges/:challengeId/attempts
GET  /api/learner/challenges/:challengeId/attempts
GET  /api/learner/challenge-attempts/:attemptId
```

## Teacher UI

Add or adapt:
- `/studio/journeys/:journeyId/challenges`
- `/studio/challenges/:challengeId/edit`
- `/studio/challenges/:challengeId/submissions`
- `/studio/challenge-attempts/:attemptId/review`

Teacher capabilities:
- create/edit/publish Challenge;
- configure points, passing percentage, attempt limit, grading mode, release and due dates;
- attach several Steps;
- see submissions;
- filter by learner/status/score/Step;
- review manual answers;
- add feedback;
- override automatic grades with audit trail;
- create and revoke private links.

## Learner UI

Show:
- title and instructions;
- questions;
- total points;
- passing percentage;
- attempt count and remaining attempts;
- deadline;
- best score;
- attempt history;
- pending review;
- teacher feedback.

Never expose answer keys.

## Private page

Create:

```text
/challenge/private/:token
```

Flow:
1. validate link metadata;
2. collect configured guest fields;
3. create anonymous session;
4. render Challenge;
5. submit attempt;
6. show safe result or pending review;
7. retain opaque result token.

## Files

For FILE_UPLOAD:
- reuse project storage;
- store metadata in PostgreSQL, not bytes;
- validate MIME, extension and size;
- use private storage and signed downloads;
- do not expose public URLs.

## Tests

Cover:
1. Challenge linked to one Step.
2. Challenge linked to several Steps.
3. Multiple attempts.
4. Attempt limits and unlimited attempts.
5. Automatic grading.
6. Fill-blank normalization.
7. Manual review.
8. Teacher override audit.
9. Best-score progress.
10. Required Challenge blocking Step completion.
11. Valid/expired/revoked/max-use private links.
12. Email/access-code restrictions.
13. Anonymous result privacy.
14. Concurrent submission.
15. Correct answers not exposed.
16. File validation.
17. Unauthorized learner/teacher access.

Run all available backend/frontend tests, lint and builds. Report every changed file and remaining TODO.
