-- Adapt all referenced table names and add real foreign keys before execution.
BEGIN;

CREATE TABLE IF NOT EXISTS challenges (
    id BIGSERIAL PRIMARY KEY,
    learning_journey_id BIGINT NOT NULL,
    created_by_user_id BIGINT NOT NULL,
    title VARCHAR(180) NOT NULL,
    description TEXT,
    instructions_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    challenge_type VARCHAR(30) NOT NULL,
    grading_mode VARCHAR(20) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'DRAFT',
    max_attempts INTEGER,
    passing_percentage NUMERIC(5,2),
    total_points NUMERIC(10,2) NOT NULL DEFAULT 100,
    is_required BOOLEAN NOT NULL DEFAULT TRUE,
    release_at TIMESTAMPTZ,
    due_at TIMESTAMPTZ,
    config_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (challenge_type IN (
        'SINGLE_CHOICE','MULTIPLE_CHOICE','TRUE_FALSE','FILL_BLANK',
        'SHORT_ANSWER','LONG_ANSWER','FILE_UPLOAD','CODING','MATCHING','ORDERING'
    )),
    CHECK (grading_mode IN ('AUTO','MANUAL','HYBRID')),
    CHECK (status IN ('DRAFT','PUBLISHED','ARCHIVED')),
    CHECK (max_attempts IS NULL OR max_attempts > 0),
    CHECK (passing_percentage IS NULL OR passing_percentage BETWEEN 0 AND 100),
    CHECK (total_points > 0)
);

CREATE INDEX IF NOT EXISTS idx_challenges_journey ON challenges(learning_journey_id);

CREATE TABLE IF NOT EXISTS challenge_steps (
    challenge_id BIGINT NOT NULL,
    step_id BIGINT NOT NULL,
    position INTEGER NOT NULL DEFAULT 0,
    is_required_for_step BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (challenge_id, step_id)
);

CREATE INDEX IF NOT EXISTS idx_challenge_steps_step ON challenge_steps(step_id);

CREATE TABLE IF NOT EXISTS challenge_questions (
    id BIGSERIAL PRIMARY KEY,
    challenge_id BIGINT NOT NULL,
    question_type VARCHAR(30) NOT NULL,
    prompt_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    options_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    config_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    points NUMERIC(10,2) NOT NULL DEFAULT 1,
    position INTEGER NOT NULL DEFAULT 0,
    is_required BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (points >= 0)
);

CREATE INDEX IF NOT EXISTS idx_challenge_questions_challenge
ON challenge_questions(challenge_id, position);

CREATE TABLE IF NOT EXISTS challenge_answer_keys (
    question_id BIGINT PRIMARY KEY,
    answer_key_json JSONB NOT NULL,
    grading_config_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS challenge_private_links (
    id BIGSERIAL PRIMARY KEY,
    challenge_id BIGINT NOT NULL,
    created_by_user_id BIGINT NOT NULL,
    token_hash CHAR(64) NOT NULL UNIQUE,
    label VARCHAR(120),
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    expires_at TIMESTAMPTZ,
    max_uses INTEGER,
    use_count INTEGER NOT NULL DEFAULT 0,
    allowed_email VARCHAR(320),
    access_code_hash TEXT,
    collect_guest_name BOOLEAN NOT NULL DEFAULT TRUE,
    collect_guest_email BOOLEAN NOT NULL DEFAULT TRUE,
    max_attempts_override INTEGER,
    last_used_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (status IN ('ACTIVE','REVOKED','EXPIRED')),
    CHECK (max_uses IS NULL OR max_uses > 0),
    CHECK (max_attempts_override IS NULL OR max_attempts_override > 0)
);

CREATE TABLE IF NOT EXISTS challenge_private_access_sessions (
    id BIGSERIAL PRIMARY KEY,
    private_link_id BIGINT NOT NULL,
    session_token_hash CHAR(64) NOT NULL UNIQUE,
    guest_name VARCHAR(180),
    guest_email VARCHAR(320),
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    attempt_count INTEGER NOT NULL DEFAULT 0,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ,
    claimed_by_user_id BIGINT,
    claimed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (status IN ('ACTIVE','EXPIRED','REVOKED','CLAIMED'))
);

CREATE TABLE IF NOT EXISTS challenge_attempts (
    id BIGSERIAL PRIMARY KEY,
    challenge_id BIGINT NOT NULL,
    learner_user_id BIGINT,
    private_access_session_id BIGINT,
    attempt_number INTEGER NOT NULL,
    status VARCHAR(25) NOT NULL DEFAULT 'SUBMITTED',
    grading_status VARCHAR(25) NOT NULL DEFAULT 'NOT_GRADED',
    raw_score NUMERIC(10,2),
    max_score NUMERIC(10,2),
    percentage NUMERIC(5,2),
    passed BOOLEAN,
    submitted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    graded_at TIMESTAMPTZ,
    graded_by_user_id BIGINT,
    teacher_feedback TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (
        (learner_user_id IS NOT NULL AND private_access_session_id IS NULL)
        OR
        (learner_user_id IS NULL AND private_access_session_id IS NOT NULL)
    ),
    CHECK (status IN ('DRAFT','SUBMITTED','COMPLETED','VOID')),
    CHECK (grading_status IN (
        'NOT_GRADED','AUTO_GRADED','PENDING_REVIEW','REVIEWED','OVERRIDDEN'
    )),
    CHECK (percentage IS NULL OR percentage BETWEEN 0 AND 100)
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_attempt_registered
ON challenge_attempts(challenge_id, learner_user_id, attempt_number)
WHERE learner_user_id IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS uq_attempt_private
ON challenge_attempts(challenge_id, private_access_session_id, attempt_number)
WHERE private_access_session_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS challenge_attempt_answers (
    id BIGSERIAL PRIMARY KEY,
    attempt_id BIGINT NOT NULL,
    question_id BIGINT NOT NULL,
    answer_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    auto_is_correct BOOLEAN,
    auto_points_awarded NUMERIC(10,2),
    final_points_awarded NUMERIC(10,2),
    grader_feedback TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (attempt_id, question_id)
);

CREATE TABLE IF NOT EXISTS learner_challenge_progress (
    id BIGSERIAL PRIMARY KEY,
    challenge_id BIGINT NOT NULL,
    learner_user_id BIGINT NOT NULL,
    status VARCHAR(25) NOT NULL DEFAULT 'NOT_STARTED',
    attempt_count INTEGER NOT NULL DEFAULT 0,
    best_attempt_id BIGINT,
    latest_attempt_id BIGINT,
    best_score NUMERIC(10,2),
    best_percentage NUMERIC(5,2),
    passed_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    started_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (challenge_id, learner_user_id),
    CHECK (status IN (
        'NOT_STARTED','IN_PROGRESS','SUBMITTED','PASSED','FAILED','PENDING_REVIEW'
    ))
);

CREATE TABLE IF NOT EXISTS challenge_attempt_grade_events (
    id BIGSERIAL PRIMARY KEY,
    attempt_id BIGINT NOT NULL,
    actor_user_id BIGINT NOT NULL,
    event_type VARCHAR(30) NOT NULL,
    previous_score NUMERIC(10,2),
    new_score NUMERIC(10,2),
    previous_percentage NUMERIC(5,2),
    new_percentage NUMERIC(5,2),
    feedback TEXT,
    metadata_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (event_type IN (
        'MANUAL_GRADE','SCORE_OVERRIDE','FEEDBACK_UPDATE','ATTEMPT_VOIDED'
    ))
);

-- Add foreign keys after adapting real table names.
COMMIT;
