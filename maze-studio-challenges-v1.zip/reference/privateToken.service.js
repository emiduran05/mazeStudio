const crypto = require("crypto");

function createToken() {
    return crypto.randomBytes(32).toString("base64url");
}

function hashToken(rawToken) {
    return crypto.createHash("sha256").update(rawToken).digest("hex");
}

module.exports = { createToken, hashToken };
