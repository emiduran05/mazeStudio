function normalizeText(value, config = {}) {
    let result = String(value ?? "").trim().replace(/\s+/g, " ");
    if (config.caseSensitive !== true) result = result.toLowerCase();
    if (config.ignoreDiacritics === true) {
        result = result.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    }
    return result;
}

function gradeQuestion({ question, key, answer }) {
    const max = Number(question.points || 0);

    if (["SINGLE_CHOICE", "TRUE_FALSE"].includes(question.questionType)) {
        const selected = answer?.selectedOptionIds?.[0] ?? null;
        const correct = selected === key.correctOptionId;
        return { correct, points: correct ? max : 0, max, manual: false };
    }

    if (question.questionType === "MULTIPLE_CHOICE") {
        const selected = new Set(answer?.selectedOptionIds || []);
        const correctSet = new Set(key.correctOptionIds || []);
        const correct =
            selected.size === correctSet.size &&
            [...selected].every((id) => correctSet.has(id));
        return { correct, points: correct ? max : 0, max, manual: false };
    }

    if (question.questionType === "FILL_BLANK") {
        const normalized = normalizeText(answer?.text, key.normalization);
        const valid = (key.acceptedAnswers || []).map((v) =>
            normalizeText(v, key.normalization)
        );
        const correct = valid.includes(normalized);
        return { correct, points: correct ? max : 0, max, manual: false };
    }

    return { correct: null, points: null, max, manual: true };
}

module.exports = { normalizeText, gradeQuestion };
